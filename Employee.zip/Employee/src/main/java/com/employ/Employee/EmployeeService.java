package com.employ.Employee;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService implements EmployeeServiceInt {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Override
	public List<Employee> saveEmployee(List<Employee> employee) {
		// TODO Auto-generated method stub
		for(Employee ee:employee)
		{
			employeeRepo.save(ee);
		}
		return employee;
	}

	
	@SuppressWarnings("unused")
	@Override
	public List<Employee> fetchEmployeeByFilter(String role_design) {
		// TODO Auto-generated method stub
		if(!role_design.equalsIgnoreCase("") || role_design!=null)
		{
		 return (List<Employee>)
				 employeeRepo.fetchEmployeeByFilter(role_design);
		}
		else
		{
			return (List<Employee>) employeeRepo.findAll();

		}
		
	}

	@Override
	public Employee updateEmployee(Employee employee, Long EmployeeId) {
		Employee emp
        = employeeRepo.findById(EmployeeId)
              .get();

    if (Objects.nonNull(employee.getEmpName())
        && !"".equalsIgnoreCase(
        		employee.getEmpName())) {
    	emp.setEmpName(
        		employee.getEmpName());
    }

    if (Objects.nonNull(
    		employee.getDesignation())
        && !"".equalsIgnoreCase(
        		employee.getDesignation())) {
    	emp.setDesignation(
    			employee.getDesignation());
    }

    if (Objects.nonNull(employee.getRole())
        && !"".equalsIgnoreCase(
        		employee.getRole())) {
        emp.setRole(
        		employee.getRole());
    }

    return employeeRepo.save(emp);
	}

	@Override
	public void deleteEmployeeById(Long id) {
		employeeRepo.deleteById(id);		
	}


	
}
