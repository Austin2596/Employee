package com.employ.Employee;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


	@Repository
	public interface EmployeeRepo extends CrudRepository<Employee, Long> {
		
		@Query("SELECT e FROM Employee e WHERE lower(e.role)=lower(:role_design) or lower(e.designation)=lower(:role_design)")
		public List<Employee> fetchEmployeeByFilter(String role_design);
		
		
	 
	     
	}

