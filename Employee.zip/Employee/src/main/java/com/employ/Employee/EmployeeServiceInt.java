package com.employ.Employee;

import java.util.List;


public interface EmployeeServiceInt {
	List<Employee> saveEmployee(List<Employee> Employee);
	 
    // Read operation
//    List<Employee> fetchEmployeeList();
    
    List<Employee> fetchEmployeeByFilter(String role_design);
 
    // Update operation
    Employee updateEmployee(Employee Employee,
                                Long id);
 
    // Delete operation
    void deleteEmployeeById(Long id);

}
