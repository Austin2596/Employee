package com.employ.Employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	@Autowired private EmployeeServiceInt employeeService;
	 
    // Save operation
    @PostMapping("/Employees")
    public List<Employee> saveEmployee(
      @RequestBody List<Employee> Employee)
    {
        return employeeService.saveEmployee(Employee);
    }
 
    // Read operation
//    @GetMapping("/Employees")
// 
//    public List<Employee> fetchEmployeeList()
//    {
//        return employeeService.fetchEmployeeList();
//    }
    
    @GetMapping("/Employees/")
    
    public List<Employee> fetchEmployeeList(@RequestParam("role_design") String role_design)
    {
        return employeeService.fetchEmployeeByFilter(role_design);
    }
 
    // Update operation
    @PutMapping("/Employees/{id}")
 
    public Employee
    updateEmployee(@RequestBody Employee employee,
                     @PathVariable("id") Long EmployeeId)
    {
        return employeeService.updateEmployee(
            employee, EmployeeId);
    }
 
    // Delete operation
    @DeleteMapping("/Employees/{id}")
 
    public String deleteEmployeeById(@PathVariable("id")
                                       Long EmployeeId)
    {
        employeeService.deleteEmployeeById(
            EmployeeId);
        return "Deleted Successfully";
    }

}
